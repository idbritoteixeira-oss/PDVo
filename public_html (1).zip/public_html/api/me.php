<?php
require_once __DIR__ . '/config/auth.php';
cors();
requireLogin();

startSession();
$tema = $_SESSION['tema'] ?? 'light';

jsonResponse([
    'user' => getCurrentUser(),
    'tema' => $tema,
]);
