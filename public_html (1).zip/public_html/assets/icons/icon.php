<?php
/**
 * PDVo — Gerador de ícone PNG para PWA
 * Uso: icon.php?size=192   icon.php?size=512&maskable=1
 * Requer: extensão GD (padrão em cPanel/PHP 7.4+)
 */

$validSizes = [72, 96, 128, 144, 152, 180, 192, 384, 512];
$size       = (int)($_GET['size'] ?? 192);
$maskable   = !empty($_GET['maskable']);

if (!in_array($size, $validSizes, true)) $size = 192;

// Tenta servir do cache
$cacheDir  = __DIR__ . '/cache';
$cacheFile = $cacheDir . '/icon-' . $size . ($maskable ? '-m' : '') . '.png';

if (file_exists($cacheFile) && filemtime($cacheFile) > time() - 86400 * 30) {
    header('Content-Type: image/png');
    header('Cache-Control: public, max-age=2592000');
    readfile($cacheFile);
    exit;
}

if (!function_exists('imagecreatetruecolor')) {
    // GD não disponível: redireciona para SVG
    header('Location: icon.svg');
    exit;
}

// ── Geração com GD ──────────────────────────────────────────
$img = imagecreatetruecolor($size, $size);
imageantialias($img, true);

// Cores
$c_bg1    = imagecolorallocate($img, 29,  78,  216);  // #1d4ed8
$c_bg2    = imagecolorallocate($img, 30,  64,  175);  // #1e40af
$c_white  = imagecolorallocate($img, 255, 255, 255);
$c_orange = imagecolorallocate($img, 249, 115,  22);  // #f97316
$c_trans  = imagecolorallocate($img, 0,   0,    0);

// Transparência
imagesavealpha($img, true);
imagealphablending($img, false);
$transparent = imagecolorallocatealpha($img, 0, 0, 0, 127);
imagefill($img, 0, 0, $transparent);
imagealphablending($img, true);

// Raio do arredondamento
$radius = $maskable ? 0 : (int)($size * 0.215);

// Desenha fundo arredondado (gradiente simulado)
_drawRoundRect($img, 0, 0, $size - 1, $size - 1, $radius, $c_bg1);

// Gradiente vertical (linha por linha)
for ($y = 0; $y < $size; $y++) {
    $ratio = $y / $size;
    $r     = (int)(29  + (30  - 29)  * $ratio);
    $g     = (int)(78  + (64  - 78)  * $ratio);
    $b     = (int)(216 + (175 - 216) * $ratio);
    $line  = imagecolorallocatealpha($img, $r, $g, $b, 0);
    // Aplica apenas dentro do arredondamento
    for ($x = 0; $x < $size; $x++) {
        if (!$maskable && !_inRoundRect($x, $y, 0, 0, $size - 1, $size - 1, $radius)) continue;
        imagesetpixel($img, $x, $y, $line);
    }
}

// Letra P via TTF ou font built-in
$fontFile = _findFont();
$letter   = 'P';

if ($fontFile && function_exists('imagettftext')) {
    $fontSize = $size * 0.52;
    $bbox     = imagettfbbox($fontSize, 0, $fontFile, $letter);
    $tw       = $bbox[2] - $bbox[0];
    $th       = abs($bbox[7] - $bbox[1]);
    $tx       = (int)(($size - $tw) / 2) - $bbox[0];
    $ty       = (int)(($size / 2) + ($th / 2)) + (int)($size * 0.04);
    imagettftext($img, $fontSize, 0, $tx, $ty, $c_white, $fontFile, $letter);
} else {
    // Fallback com imagestring (menos bonito, mas funciona)
    $fs = ($size > 100) ? 5 : (($size > 50) ? 4 : 3);
    $fw = imagefontwidth($fs);
    $fh = imagefontheight($fs);
    $repeat = max(1, (int)($size / 60));
    $tx = (int)(($size - $fw * $repeat) / 2);
    $ty = (int)(($size - $fh * $repeat) / 2);
    imagestring($img, $fs, $tx, $ty, $letter, $c_white);
}

// Ponto laranja (decorativo — canto inferior direito)
$dotR  = (int)($size * 0.082);
$dotCx = (int)($size * 0.752);
$dotCy = (int)($size * 0.782);
imagefilledellipse($img, $dotCx, $dotCy, $dotR * 2, $dotR * 2, $c_orange);
imagefilledellipse($img, $dotCx, $dotCy, (int)($dotR * 1.09), (int)($dotR * 1.09), $c_white);

// Salva em cache
if (!is_dir($cacheDir)) @mkdir($cacheDir, 0755, true);
@imagepng($img, $cacheFile);

// Entrega ao browser
header('Content-Type: image/png');
header('Cache-Control: public, max-age=2592000');
imagepng($img);
imagedestroy($img);

// ── Helpers ─────────────────────────────────────────────────

function _drawRoundRect($img, $x1, $y1, $x2, $y2, $r, $color): void {
    imagefilledrectangle($img, $x1 + $r, $y1, $x2 - $r, $y2, $color);
    imagefilledrectangle($img, $x1, $y1 + $r, $x2, $y2 - $r, $color);
    imagefilledellipse($img, $x1 + $r, $y1 + $r, $r * 2, $r * 2, $color);
    imagefilledellipse($img, $x2 - $r, $y1 + $r, $r * 2, $r * 2, $color);
    imagefilledellipse($img, $x1 + $r, $y2 - $r, $r * 2, $r * 2, $color);
    imagefilledellipse($img, $x2 - $r, $y2 - $r, $r * 2, $r * 2, $color);
}

function _inRoundRect($px, $py, $x1, $y1, $x2, $y2, $r): bool {
    if ($px < $x1 || $px > $x2 || $py < $y1 || $py > $y2) return false;
    if ($px < $x1 + $r && $py < $y1 + $r) return _inCircle($px, $py, $x1 + $r, $y1 + $r, $r);
    if ($px > $x2 - $r && $py < $y1 + $r) return _inCircle($px, $py, $x2 - $r, $y1 + $r, $r);
    if ($px < $x1 + $r && $py > $y2 - $r) return _inCircle($px, $py, $x1 + $r, $y2 - $r, $r);
    if ($px > $x2 - $r && $py > $y2 - $r) return _inCircle($px, $py, $x2 - $r, $y2 - $r, $r);
    return true;
}

function _inCircle($px, $py, $cx, $cy, $r): bool {
    return (($px - $cx) ** 2 + ($py - $cy) ** 2) <= $r ** 2;
}

function _findFont(): ?string {
    $candidates = [
        '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
        '/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf',
        '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf',
        '/usr/share/fonts/truetype/freefont/FreeSansBold.ttf',
        '/usr/share/fonts/TTF/DejaVuSans-Bold.ttf',
        '/Library/Fonts/Arial Bold.ttf',
        'C:\\Windows\\Fonts\\arialbd.ttf',
    ];
    foreach ($candidates as $f) {
        if (file_exists($f)) return $f;
    }
    return null;
}
